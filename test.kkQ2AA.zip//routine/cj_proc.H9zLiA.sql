create
    definer = root@localhost procedure cj_proc(IN xm1 varchar(4))
begin
        begin
          delete from xmcj_view;
      end;
        begin
          insert into xmcj_view(select kcm,cj1 from cj where xm=xm1);
      end;
    end;

