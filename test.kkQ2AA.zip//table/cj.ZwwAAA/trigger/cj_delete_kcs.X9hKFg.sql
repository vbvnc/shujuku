create definer = root@localhost trigger cj_delete_kcs
    after delete
    on cj
    for each row
begin
update xs set kcs =kcs -1 where xm=old.xm;
end;

