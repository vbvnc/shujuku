create definer = root@localhost trigger cj_insert_kcs
    after insert
    on cj
    for each row
begin
    update xs set kcs=kcs+1 where new.xm=xm;
end;

